from os import name
from uuid import UUID

from sqlalchemy import delete, func, insert, select, update
from sqlalchemy.ext.asyncio import AsyncSession
from src.domain.products.entities import ProductVariant
from src.domain.products.repository import ProductVariantRepositoryInterface
from src.infrastructure.persistence.postgresql.models.product import (
    ProductVariantModel,
    map_to_product_variant,
)


class SqlalchemyProductVariantRepository(ProductVariantRepositoryInterface):
    __slots__ = ["session"]

    def __init__(self, session: AsyncSession) -> None:
        self.session = session

    async def create(self, product_variant: ProductVariant) -> None:
        query = insert(ProductVariantModel).values(
            id=product_variant.id,
            product_id=product_variant.product_id,
            name=product_variant.name,
            sku=product_variant.sku,
            bag_weight=product_variant.bag_weight,
            pallet_weight=product_variant.pallet_weight,
            bags_per_pallet=product_variant.bags_per_pallet,
            image=product_variant.image,
        )

        await self.session.execute(query)

        return None

    async def delete(self, product_variant_id: UUID) -> None:
        query = delete(ProductVariantModel).where(
            ProductVariantModel.id == product_variant_id
        )

        await self.session.execute(query)

        return None

    async def get_by_id(self, product_variant_id: UUID) -> ProductVariant | None:
        query = select(ProductVariantModel).where(
            ProductVariantModel.id == product_variant_id
        )

        cursor = await self.session.execute(query)

        entity = cursor.scalar_one_or_none()

        return map_to_product_variant(entity) if entity else None

    async def get_many_by_ids(
        self, product_variant_ids: set[UUID]
    ) -> tuple[list[ProductVariant], set[UUID]]:
        query = select(ProductVariantModel).where(
            ProductVariantModel.id.in_(product_variant_ids)
        )

        cursor = await self.session.execute(query)

        entities = cursor.scalars().all()

        missing_product_variant_ids: set[UUID] = set()
        product_variants: list[ProductVariant] = []

        for entity in entities:
            if entity.id not in product_variant_ids:
                missing_product_variant_ids.add(entity.id)
            else:
                product_variants.append(map_to_product_variant(entity))

        return product_variants, missing_product_variant_ids

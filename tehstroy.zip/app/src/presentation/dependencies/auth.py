import logging
from typing import Annotated, Dict, Optional

from dishka import AsyncContainer
from fastapi import Depends, Request, WebSocket
from fastapi.openapi.models import OAuthFlowPassword
from fastapi.openapi.models import OAuthFlows as OAuthFlowsModel
from fastapi.security import OAuth2, SecurityScopes
from fastapi.security.utils import get_authorization_scheme_param
from src.application.auth.dto import UserTokenData
from src.application.auth.exceptions import (
    NotAuthorizedException,
    NotEnoughPermissionsException,
)
from src.application.common.interfaces.identity_provider import (
    IdentityProviderInterface,
)
from src.infrastructure.di.container import get_container

logger = logging.getLogger()


class OAuth2PasswordBearerWithCookie(OAuth2):
    def __init__(
        self,
        tokenUrl: str,
        scheme_name: Optional[str] = None,
        scopes: Optional[Dict[str, str]] = None,
        auto_error: bool = False,
    ):
        if not scopes:
            scopes = {}
        flows = OAuthFlowsModel(
            password=OAuthFlowPassword(tokenUrl=tokenUrl, scopes=scopes),
        )
        super().__init__(flows=flows, scheme_name=scheme_name, auto_error=auto_error)

    async def __call__(self, request: Request) -> Optional[str]:
        authorization: str | None = request.cookies.get("access_token")

        scheme, param = get_authorization_scheme_param(authorization)
        if not authorization or scheme.lower() != "bearer":
            if self.auto_error:
                raise NotAuthorizedException
            else:
                return None
        return param


oauth2_scheme = OAuth2PasswordBearerWithCookie(
    tokenUrl="/api/v1/auth/login",
    scopes={
        "user": "Basic rights",
        "admin": "Admin rights",
    },
)


def _get_token_data(value: str | None) -> str:
    scheme, param = get_authorization_scheme_param(value)

    if not value or scheme.lower() != "bearer":
        raise NotAuthorizedException

    return param


async def get_refresh_token(
    request: Request,
) -> str:
    refresh_token: str | None = request.cookies.get("refresh_token")

    return _get_token_data(value=refresh_token)


async def auth_required(
    request: Request,
    authorization: Annotated[
        str,
        Depends(oauth2_scheme),
    ],
) -> None:
    if not authorization:
        raise NotAuthorizedException

    request.scope["auth"] = authorization


async def get_current_user_data(
    security_scopes: SecurityScopes,
    authorization: Annotated[
        str,
        Depends(oauth2_scheme),
    ],
    container: AsyncContainer = Depends(get_container),
) -> UserTokenData:
    if not authorization:
        raise NotAuthorizedException

    identity_provider = await container.get(IdentityProviderInterface)

    user_data = await identity_provider.get_current_user(authorization=authorization)

    for scope in security_scopes.scopes:
        if scope not in user_data.scopes:
            raise NotEnoughPermissionsException

    return user_data


async def get_current_user_from_websocket(
    websocket: WebSocket,
    container: AsyncContainer,
) -> UserTokenData:
    access_token: str | None = websocket.cookies.get("access_token")

    authorization = _get_token_data(value=access_token)

    identity_provider = await container.get(IdentityProviderInterface)

    user_data = await identity_provider.get_current_user(authorization=authorization)

    return user_data

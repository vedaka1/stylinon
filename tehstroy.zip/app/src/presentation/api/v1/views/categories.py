import logging
from typing import Annotated
from uuid import UUID

from dishka import AsyncContainer
from dishka.integrations.fastapi import DishkaRoute, FromDishka
from fastapi import APIRouter, Depends, Security, WebSocket, WebSocketDisconnect
from src.application.auth.dto import UserTokenData
from src.application.auth.exceptions import (
    NotAuthorizedException,
    TokenExpiredException,
)
from src.application.chats.commands import (
    CreateChatCommand,
    CreateMessageCommand,
    GetChatsListCommand,
)
from src.application.chats.dto import ChatOut
from src.application.chats.interface import WebsocketManagerInterface
from src.application.chats.usecases.create import (
    CreateChatUseCase,
    CreateMessageUseCase,
)
from src.application.chats.usecases.get import GetChatsListUseCase, GetChatUseCase
from src.application.common.pagination import ListPaginatedResponse, PaginationQuery
from src.application.common.response import APIResponse
from src.application.products.commands import CreateCategoryCommand
from src.application.products.usecases.create import CreateCategoryUseCase
from src.application.products.usecases.delete import DeleteCategoryUseCase
from src.application.products.usecases.get import GetCategoriesListUseCase
from src.domain.products.entities import Category
from src.domain.users.entities import UserRole
from src.infrastructure.di.container import get_container
from src.presentation.dependencies.auth import get_current_user_data

router = APIRouter(
    tags=["Categories"],
    prefix="/categories",
    route_class=DishkaRoute,
)


@router.post(
    "",
    dependencies=[
        Security(
            get_current_user_data,
            scopes=[
                UserRole.ADMIN.value,
                UserRole.MANAGER.value,
            ],
        )
    ],
)
async def create_category(
    command: CreateCategoryCommand,
    create_category_interactor: FromDishka[CreateCategoryUseCase],
) -> APIResponse[None]:
    await create_category_interactor.execute(command=command)

    return APIResponse()


@router.get("")
async def get_categories(
    get_categories_list_interactor: FromDishka[GetCategoriesListUseCase],
) -> APIResponse[list[Category]]:
    response = await get_categories_list_interactor.execute()

    return APIResponse(data=response)


@router.delete("/{category_name}")
async def delete_category(
    category_name: str,
    delete_category_interactor: FromDishka[DeleteCategoryUseCase],
) -> APIResponse[None]:
    await delete_category_interactor.execute(category_name=category_name)

    return APIResponse()

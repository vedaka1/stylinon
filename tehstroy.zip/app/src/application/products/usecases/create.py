from dataclasses import dataclass

from src.application.common.interfaces.transaction import TransactionManagerInterface
from src.application.products.commands import (
    CreateCategoryCommand,
    CreateProductCommand,
)
from src.domain.products.entities import Category, Product
from src.domain.products.repository import (
    CategoryRepositoryInterface,
    ProductRepositoryInterface,
)


@dataclass
class CreateProductUseCase:

    product_repository: ProductRepositoryInterface
    transaction_manager: TransactionManagerInterface

    async def execute(self, command: CreateProductCommand) -> None:
        product = Product.create(
            name=command.name,
            category=command.category,
            description=command.description,
            units_of_measurement=command.units_of_measurement,
        )

        await self.product_repository.create(product)

        await self.transaction_manager.commit()

        return None


@dataclass
class CreateCategoryUseCase:

    category_repository: CategoryRepositoryInterface
    transaction_manager: TransactionManagerInterface

    async def execute(self, command: CreateCategoryCommand) -> None:
        category = Category.create(name=command.name)

        await self.category_repository.create(category=category)

        await self.transaction_manager.commit()

        return None
